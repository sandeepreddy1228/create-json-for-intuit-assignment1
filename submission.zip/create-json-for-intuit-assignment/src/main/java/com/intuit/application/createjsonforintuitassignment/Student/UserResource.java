package com.intuit.application.createjsonforintuitassignment.Student;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserResource {
     @Autowired
	private StudentDaoService studentDaoService;
	
     @GetMapping("/students")
     public List<Student> retriveAllusers()
	{
		return studentDaoService.findAll() ;
		
	}
     @GetMapping("/students/{id}")
     public  Student retriveUser(@PathVariable int id)
     {
    	 
		return studentDaoService.findOne(id);
    	 
		
     }
     @PostMapping("/students")
     public  void createStudent(@RequestBody Student student)
     {
    	Student savedStudent= studentDaoService.save(student);
     }
}
