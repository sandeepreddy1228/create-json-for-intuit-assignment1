package com.intuit.application.createjsonforintuitassignment.Student;


import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class StudentDaoService {
private static List<Student> students = new ArrayList();
static
{
students.add(new Student(1,"sandeep","chintakuntla", true));
}

public List<Student> findAll()
{
	return students;
	
}
public Student save(Student student)
{
	students.add(student);
	return student;
	
}
public Student findOne(int id)
{
	for(Student student:students)
	{
		if(student.getId()==id)
		{
			return student;
		}
	}
	return null;
}
}
