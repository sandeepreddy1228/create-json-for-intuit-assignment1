package com.intuit.application.createjsonforintuitassignment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CreateJsonForIntuitAssignmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(CreateJsonForIntuitAssignmentApplication.class, args);
	}
}
