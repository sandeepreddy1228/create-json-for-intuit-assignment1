package com.intuit.application.createjsonforintuitassignment.Student;

import java.io.File;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.ObjectMapper;

public class Driver {

	public static void main(String[] args) {
		try
		{
			//create object mapper
			ObjectMapper mapper =new ObjectMapper();
			//read json file in pojo
			Student thestudent =mapper.readValue(new File("data/sample-full.json"),Student.class);
			//data/sample.lite.json
			//print lastname and first name
			System.out.println("print firstname "+thestudent.getLastName());
			System.out.println("print last name "+thestudent.getFirstName());
			
			Address theaddress =thestudent.getAddress();
			System.out.println("Address "+theaddress.getCity());
			
			for(String mylanguage:thestudent.getLanguages())
			{
				System.out.println(mylanguage);
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}

}
